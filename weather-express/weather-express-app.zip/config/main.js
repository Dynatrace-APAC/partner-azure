module.exports = {
  
weatherserviceUri: "https://wrong-weather-service.azurewebsites.net/weather",

redisHost: "partner-workshop-redis.redis.cache.windows.net",
redisPort: 6379,
redisPass: "Cujkysjap6lHUW9HhbII1q1Jxo2V9unZq5cfRMpWNOc=",

    port: 8100,
    portS: 8581
};