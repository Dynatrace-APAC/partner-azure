module.exports = {
  
weatherserviceUri: "https://apacbootcamp-weather-service.azurewebsites.net/weather",

redisHost: "p1az-redis.redis.cache.windows.net",
redisPort: 6379,
redisPass: "HBMcbRhdp8PNk89VgWqAYTLOPbB0O3oX4Mk9yrf64LA=",

    port: 8100,
    portS: 8581
};